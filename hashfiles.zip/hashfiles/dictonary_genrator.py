import itertools


def generate_dictionary():
   # expand this a bit


    words_8 = ["password", "standard", "security", "learning", "computer","november",
               "kittycat","february","december","holidays"]
    years = [str(y) for y in range(1990, 2031)]
    digits = [f"{i:04}" for i in range(100)]
    words_4 = ["blue", "bolt", "fire", "cold", "kind", "fast","feet","dogs","june",
               "july","cats,grow"]
    words_5=["green","grass"]
    words_7=["october","quarter"]

    with open("dictionary_12_.txt", "w") as f:
        # Generate 8+4 combinations
        for w, d in itertools.product(words_8, digits):
            f.write(f"{w}{d}\n")

        for i,s in itertools.product(words_5, words_7):
            f.write(f"{i}{s}\n")


        for combo in itertools.product(words_4, repeat=3):
         f.write(f"{''.join(combo)}\n")

generate_dictionary()
print(f"Dictionary 'dictionary_12.txt' created successfully.")

