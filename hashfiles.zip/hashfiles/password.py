import random
import string
import hashlib
import bcrypt
import time

def encrypt_password(password):
  password_md5 = hashlib.md5(password.encode()).hexdigest()
  password_sha256 = hashlib.sha256(password.encode()).hexdigest()
  password_bcrypt= bcrypt.hashpw(password, bcrypt.gensalt())
  return password_md5, password_sha256, password_bcrypt



def password():
  password = ""

  for i in range(0,13): #just to be more explicit
   password += random.choice(characters_current)

  return password

def listofcharacters():
  characters = list(string.ascii_letters)
  characters += list(string.digits)
  characters += list(string.punctuation)
  return characters

def acceptstring(password):
  if len(password) < 13:
    return "Not enough characters" #use this to reject passwords, may change this
  return password


characters_current = listofcharacters()
def dictonaryattack_md5(password_md5,dictonary):
 for i in dictonary:

   attempted_password=hashlib.md5(i.encode('utf-8')).hexdigest()
   if attempted_password == password_md5:
     return i
 return None

def dictonaryattack_sha_256(password_sha_256,dictonary):
 for i in dictonary:
   attempted_password=hashlib.sha256(i.encode('utf-8')).hexdigest()
   if attempted_password == password_sha_256:
     return i
 return None



def dictonaryattack_bcrypt(password_bcrypt,dictonary):
  for i in dictonary:
   if bcrypt.checkpw(i.encode('utf-8'),password_bcrypt):
     return i
  return None


def load_dictionary(filename):
    with open(filename, "r") as f:
        return [line.strip() for line in f]



password=password()
dictonary=load_dictionary("dictionary_12.txt")
md5_password,sha_password,bcrypt_password=encrypt_password(password)
start_md5 = time.perf_counter()
result_md5 = dictonaryattack_md5(md5_password, dictonary)
end_md5 = time.perf_counter()

start_sha = time.perf_counter()
result_sha=dictonaryattack_sha_256(sha_password,dictonary)
end_sha = time.perf_counter()

start_bcyrpt = time.perf_counter()
result_bcyrpt=dictonaryattack_bcrypt(bcrypt_password,dictonary)
end_bcyrpt = time.perf_counter()



print("MD5 crack time:", end_md5 - start_md5,"Result:",result_md5)
print("SHA crack time:", end_sha - start_sha,"Result:",result_sha)
print("Bcrypt crack time:", end_bcyrpt-start_bcyrpt,"Result:",result_bcyrpt)